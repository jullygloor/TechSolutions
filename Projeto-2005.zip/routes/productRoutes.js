const express = require('express');
const router = express.Router();
const controller = require('../app/controllers/productController');

router.get('/produtos', controller.list);
router.get('/produtos/create', controller.createForm);
router.post('/produtos/create', controller.create);
router.get('/produtos/edit/:id', controller.editForm);
router.post('/produtos/edit/:id', controller.update);
router.get('/produtos/delete/:id', controller.delete);

module.exports = router;