const Product = require('../models/productModel');

exports.list = (req, res) => {
  Product.findAll((err, results) => {
    if (err) throw err;
    res.render('products/index', { produtos: results });
  });
};

exports.createForm = (req, res) => {
  res.render('products/create');
};

exports.create = (req, res) => {
  const data = req.body;
  Product.create(data, (err) => {
    if (err) throw err;
    res.redirect('/produtos');
  });
};

exports.editForm = (req, res) => {
  Product.findById(req.params.id, (err, results) => {
    if (err) throw err;
    res.render('products/edit', { produto: results[0] });
  });
};

exports.update = (req, res) => {
  const data = req.body;
  Product.update(req.params.id, data, (err) => {
    if (err) throw err;
    res.redirect('/produtos');
  });
};

exports.delete = (req, res) => {
  Product.delete(req.params.id, (err) => {
    if (err) throw err;
    res.redirect('/produtos');
  });
};