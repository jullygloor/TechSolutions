const db = require('../../config/database');

module.exports = {
  findAll(callback) {
    db.query('SELECT * FROM produtos', callback);
  },
  findById(id, callback) {
    db.query('SELECT * FROM produtos WHERE id = ?', [id], callback);
  },
  create(data, callback) {
    db.query('INSERT INTO produtos SET ?', data, callback);
  },
  update(id, data, callback) {
    db.query('UPDATE produtos SET ? WHERE id = ?', [data, id], callback);
  },
  delete(id, callback) {
    db.query('DELETE FROM produtos WHERE id = ?', [id], callback);
  }
};