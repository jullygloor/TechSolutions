const express = require('express');
const path = require('path');
const app = express();
require('dotenv').config();
const productRoutes = require('./routes/productRoutes');

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'app/views'));
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));

app.use('/', productRoutes);

app.listen(3000, () => console.log('Servidor rodando em http://localhost:3000/produtos'));